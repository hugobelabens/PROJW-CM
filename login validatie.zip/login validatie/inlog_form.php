<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h2>Login</h2>
	<form method="POST" action="login_process.php">
		<label for="username">Username:</label>
		<input type="text" name="username" id="username"><br><br>
		<label for="password">Password:</label>
		<input type="password" name="password" id="password"><br><br>
		<input type="submit" name="submit" value="Login">
	</form>
</body>
</html>
