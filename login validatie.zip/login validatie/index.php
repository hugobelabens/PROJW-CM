<!DOCTYPE html>
<html>
<head>
	<title>Index pagina</title>
</head>
<body>
	<h1>Welkom op de indexpagina</h1>
	<p>Kies een optie:</p>
	<ul>
		<li><a href="inlog_form.php">Inloggen</a></li>
		<li><a href="registratie_form.php">Registreren</a></li>
	</ul>
</body>
</html>

