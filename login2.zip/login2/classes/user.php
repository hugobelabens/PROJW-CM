class User {
    private $PROJW-CM;
    private $username;
    private $loggedin;

    function __construct() {
        $this->PROJW-CM = new Database();
        $this->loggedin = false;
    }

    // Check of de gebruiker is ingelogd
    public function IsLoggedIn() {
        if ($this->loggedin) {
            return true;
        } else if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
            $user = $this->GetUser($username);
            if ($user != null) {
                $this->username = $username;
                $this->loggedin = true;
                return true;
            }
        }
        return false;
    }

    // Log de gebruiker uit
    public function Logout() {
        session_destroy();
        $this->loggedin = false;
    }

    // Haal de gebruikersinformatie op
    public function GetUser($username) {
        $query = "SELECT * FROM users WHERE username = ?";
        $params = array($username);
        $result = $this->db->query($query, $params);
        if ($result != null && count($result) > 0) {
            return $result[0];
        } else {
            return null;
        }
    }
}
